#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Produto {
    char nome[30];
    int codigo;
    double preco;
};

int main() {
    struct Produto estoque[10];

    strcpy(estoque[0].nome, "Pe de Moleque");
    estoque[0].codigo = 13205;
    estoque[0].preco = 0.20;

    strcpy(estoque[1].nome, "Cocada Baiana");
    estoque[1].codigo = 15202;
    estoque[1].preco = 0.50;

    struct Produto *estoque_ptr = (struct Produto *)malloc(10 * sizeof(struct Produto));

    if (estoque_ptr == NULL) {
        printf("Erro na aloca��o de mem�ria\n");
        return 1;
    }
    strcpy(estoque_ptr[0].nome, "Pe de Moleque");
    estoque_ptr[0].codigo = 13205;
    estoque_ptr[0].preco = 0.20;

    strcpy(estoque_ptr[1].nome, "Cocada Baiana");
    estoque_ptr[1].codigo = 15202;
    estoque_ptr[1].preco = 0.50;

    printf("Matriz de Produto:\n");
    for (int i = 0; i < 2; i++) {
        printf("Produto %d:\n", i + 1);
        printf("Nome: %s\n", estoque[i].nome);
        printf("C�digo: %d\n", estoque[i].codigo);
        printf("Pre�o: R$%.2lf\n", estoque[i].preco);
        printf("\n");
    }

    printf("Ponteiro para Produto:\n");
    for (int i = 0; i < 2; i++) {
        printf("Produto %d:\n", i + 1);
        printf("Nome: %s\n", estoque_ptr[i].nome);
        printf("C�digo: %d\n", estoque_ptr[i].codigo);
        printf("Pre�o: R$%.2lf\n", estoque_ptr[i].preco);
        printf("\n");
    }
    free(estoque_ptr);

    return 0;
}
