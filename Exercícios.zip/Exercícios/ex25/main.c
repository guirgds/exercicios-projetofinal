#include <stdio.h>

int EDivisivel(int a, int b) {
    if (b == 0) {
        printf("Erro: Divis�o por zero n�o � permitida.\n");
        return -1;
    }

    if (a % b == 0) {
        return 1;
    } else {
        return 0;
    }
}
int main() {
    int a, b;
    printf("Digite dois n�meros inteiros (a e b): ");
    scanf("%d %d", &a, &b);

    int resultado = EDivisivel(a, b);

    if (resultado == 1) {
        printf("%d � divis�vel por %d.\n", a, b);
    } else if (resultado == 0) {
        printf("%d n�o � divis�vel por %d.\n", a, b);
    }

    return 0;
}
