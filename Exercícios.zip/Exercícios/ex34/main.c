#include <stdio.h>
int fibonacci(int n) {
    int a = 0, b = 1, resultado = 0;

    if (n <= 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    }

    for (int i = 2; i <= n; i++) {
        resultado = a + b;
        a = b;
        b = resultado;
    }

    return resultado;
}

int main() {
    int n;

    printf("Digite o valor de n para encontrar o enesimo termo da serie de Fibonacci: ");
    scanf("%d", &n);

    if (n < 1) {
        printf("O valor de n deve ser um inteiro positivo.\n");
        return 1;
    }

    int resultado = fibonacci(n);

    printf("O %d-esimo termo da serie de Fibonacci e: %d\n", n, resultado);

    return 0;
}
