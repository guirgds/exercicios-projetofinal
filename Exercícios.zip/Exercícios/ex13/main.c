#include <stdio.h>

int main() {
    int dia, mes, ano;

    do {
        printf("Digite o dia, m�s e ano (dd mm aaaa): ");
        scanf("%d %d %d", &dia, &mes, &ano);

        if ((dia < 1 || dia > 31) || (mes < 1 || mes > 12) || (ano < 1900 || ano > 2100)) {
            printf("Valores inv�lidos. Por favor, insira valores dentro das faixas corretas.\n");
        }
    } while ((dia < 1 || dia > 31) || (mes < 1 || mes > 12) || (ano < 1900 || ano > 2100));
    int bissexto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
    int diasNoMes[] = {0, 31, 28 + bissexto, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (dia > diasNoMes[mes]) {
        printf("Valores inv�lidos. O m�s %d n�o possui %d dias.\n", mes, dia);
    } else {
        int diaDoAno = dia;
        for (int i = 1; i < mes; i++) {
            diaDoAno += diasNoMes[i];
        }
        printf("O dia %d do m�s %d do ano %d corresponde ao dia %d do ano.\n", dia, mes, ano, diaDoAno);
    }

    return 0;
}
