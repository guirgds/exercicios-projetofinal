 /* void main()  esse programa esta errado
{
    int x, *p;
    x = 10;
    *p = x;
}*/
#include <stdio.h>
int main()
{
    int x, *p;
    x = 10;
    p = &x;
    printf("%d", *p);
    return 0;
}
