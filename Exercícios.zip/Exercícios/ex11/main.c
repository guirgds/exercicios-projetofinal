#include <stdio.h>
#include <string.h>

int main() {
    char original[100];
    char invertida[100];
    int i, j;
    printf("Digite uma string: ");
    gets(original);
    int tamanho = strlen(original);
    for (i = tamanho - 1, j = 0; i >= 0; i--, j++) {
        invertida[j] = original[i];
    }
    invertida[j] = '\0';
    printf("String original: %s\n", original);
    printf("String invertida: %s\n", invertida);
    return 0;
}
