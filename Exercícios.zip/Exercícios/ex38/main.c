#include <stdio.h>

int main() {
    FILE *arquivo;
    char nome_arquivo[100];
    char caractere;
    int contador = 0;

    printf("Digite o nome do arquivo: ");
    scanf("%s", nome_arquivo);

    arquivo = fopen(nome_arquivo, "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }
    while ((caractere = fgetc(arquivo)) != EOF) {
        contador++;
    }

    fclose(arquivo);

    printf("N�mero de caracteres no arquivo: %d\n", contador);

    return 0;
}
