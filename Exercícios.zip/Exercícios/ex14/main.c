#include <stdio.h>
#include <stdlib.h>

void decimalParaHexadecimal() {
    int decimal;
    printf("Digite um n�mero decimal: ");
    scanf("%d", &decimal);
    printf("O n�mero hexadecimal correspondente �: %X\n", decimal);
}
void hexadecimalParaDecimal() {
    char hexadecimal[20];
    printf("Digite um n�mero hexadecimal: ");
    scanf("%s", hexadecimal);
    int decimal = strtol(hexadecimal, NULL, 16);
    printf("O n�mero decimal correspondente �: %d\n", decimal);
}
void decimalParaOctal() {
    int decimal;
    printf("Digite um n�mero decimal: ");
    scanf("%d", &decimal);
    printf("O n�mero octal correspondente �: %o\n", decimal);
}
void octalParaDecimal() {
    char octal[20];
    printf("Digite um n�mero octal: ");
    scanf("%s", octal);
    int decimal = strtol(octal, NULL, 8);
    printf("O n�mero decimal correspondente �: %d\n", decimal);
}

int main() {
    int opcao;

    do {
        printf("< Conversao de base >\n");
        printf("1: Decimal para hexadecimal\n");
        printf("2: Hexadecimal para decimal\n");
        printf("3: Decimal para octal\n");
        printf("4: Octal para decimal\n");
        printf("5: Encerra\n");
        printf("Informe sua opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                decimalParaHexadecimal();
                break;
            case 2:
                hexadecimalParaDecimal();
                break;
            case 3:
                decimalParaOctal();
                break;
            case 4:
                octalParaDecimal();
                break;
            case 5:
                printf("Programa encerrado.\n");
                break;
            default:
                printf("Opcao invalida. Tente novamente.\n");
        }

    } while (opcao != 5);

    return 0;
}
