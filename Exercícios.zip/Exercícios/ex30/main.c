#include <stdio.h>

#define E_IMPAR(x) ((x) % 2 != 0)

int main() {
    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    if (E_IMPAR(numero)) {
        printf("%d e impar.\n", numero);
    } else {
        printf("%d e par.\n", numero);
    }

    return 0;
}
