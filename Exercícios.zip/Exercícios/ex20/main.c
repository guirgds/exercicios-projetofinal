#include <stdio.h>
#include <string.h>

int strend(char *s, char *t) {
    int s_len = strlen(s);
    int t_len = strlen(t);
    if (t_len > s_len) {
        return 0;
    }
    s += s_len - t_len;

    while (*s != '\0' && *t != '\0') {
        if (*s != *t) {
            return 0;
        }
        s++;
        t++;
    }
    return (*t == '\0') ? 1 : 0;
}

int main() {
    char s[] = "Hello, world!";
    char t1[] = "world!";
    char t2[] = "hello";

    if (strend(s, t1)) {
        printf("'%s' ocorre no final de '%s'\n", t1, s);
    } else {
        printf("'%s' n�o ocorre no final de '%s'\n", t1, s);
    }

    if (strend(s, t2)) {
        printf("'%s' ocorre no final de '%s'\n", t2, s);
    } else {
        printf("'%s' n�o ocorre no final de '%s'\n", t2, s);
    }

    return 0;
}
