#include <stdio.h>

int main() {
    char nome[100];
    printf("Digite um nome: ");
    gets(nome);
    printf("Nome digitado: ");
    puts(nome);
    return 0;
}
