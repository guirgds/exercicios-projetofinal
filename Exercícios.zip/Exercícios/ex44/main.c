#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Restaurante {
    char nome[100];
    char endereco[100];
    char tipoComida[50];
    double notaCozinha;
    struct Restaurante *prox;
};
struct Restaurante *inserirRestaurante(struct Restaurante *lista, const char *nome, const char *endereco, const char *tipoComida, double notaCozinha) {
    struct Restaurante *novoRestaurante = (struct Restaurante *)malloc(sizeof(struct Restaurante));
    if (novoRestaurante == NULL) {
        printf("Erro na aloca��o de mem�ria.\n");
        return lista;
    }

    strncpy(novoRestaurante->nome, nome, sizeof(novoRestaurante->nome));
    strncpy(novoRestaurante->endereco, endereco, sizeof(novoRestaurante->endereco));
    strncpy(novoRestaurante->tipoComida, tipoComida, sizeof(novoRestaurante->tipoComida));
    novoRestaurante->notaCozinha = notaCozinha;
    novoRestaurante->prox = lista;

    return novoRestaurante;
}
void listarRestaurantes(struct Restaurante *lista) {
    struct Restaurante *atual = lista;
    while (atual != NULL) {
        printf("Nome: %s\n", atual->nome);
        printf("Endere�o: %s\n", atual->endereco);
        printf("Tipo de Comida: %s\n", atual->tipoComida);
        printf("Nota da Cozinha: %.2lf\n", atual->notaCozinha);
        printf("\n");
        atual = atual->prox;
    }
}
void listarRestaurantesPorNota(struct Restaurante *lista, double notaMinima) {
    struct Restaurante *atual = lista;
    while (atual != NULL) {
        if (atual->notaCozinha >= notaMinima) {
            printf("Nome: %s\n", atual->nome);
            printf("Endere�o: %s\n", atual->endereco);
            printf("Tipo de Comida: %s\n", atual->tipoComida);
            printf("Nota da Cozinha: %.2lf\n", atual->notaCozinha);
            printf("\n");
        }
        atual = atual->prox;
    }
}
void listarRestaurantesPorTipoComida(struct Restaurante *lista, const char *tipo) {
    struct Restaurante *atual = lista;
    while (atual != NULL) {
        if (strcmp(atual->tipoComida, tipo) == 0) {
            printf("Nome: %s\n", atual->nome);
            printf("Endere�o: %s\n", atual->endereco);
            printf("Tipo de Comida: %s\n", atual->tipoComida);
            printf("Nota da Cozinha: %.2lf\n", atual->notaCozinha);
            printf("\n");
        }
        atual = atual->prox;
    }
}
void liberarLista(struct Restaurante *lista) {
    struct Restaurante *atual = lista;
    while (atual != NULL) {
        struct Restaurante *prox = atual->prox;
        free(atual);
        atual = prox;
    }
}

int main() {
    struct Restaurante *lista = NULL;
    int opcao;

    do {
        printf("Escolha uma op��o:\n");
        printf("1. Inserir um novo restaurante\n");
        printf("2. Listar todos os restaurantes\n");
        printf("3. Listar restaurantes por nota m�nima\n");
        printf("4. Listar restaurantes por tipo de comida\n");
        printf("5. Sair\n");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: {
                char nome[100], endereco[100], tipoComida[50];
                double notaCozinha;
                printf("Nome do restaurante: ");
                scanf("%s", nome);
                printf("Endere�o do restaurante: ");
                scanf("%s", endereco);
                printf("Tipo de comida: ");
                scanf("%s", tipoComida);
                printf("Nota da cozinha: ");
                scanf("%lf", &notaCozinha);

                lista = inserirRest
