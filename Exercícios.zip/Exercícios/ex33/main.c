#include <stdio.h>

int fibonacci(int n) {
    if (n <= 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        int a = 0;
        int b = 1;
        int resultado = 0;

        for (int i = 2; i <= n; i++) {
            resultado = a + b;
            a = b;
            b = resultado;
        }

        return resultado;
    }
}
int main() {
    int n;
    printf("Digite o valor de n para encontrar o enesimo termo da serie de Fibonacci: ");
    scanf("%d", &n);
    if (n < 0) {
        printf("O valor de n deve ser nao negativo.\n");
        return 1;
    }
    int resultado = fibonacci(n);
    printf("O %d-esimo termo da serie de Fibonacci e: %d\n", n, resultado);

    return 0;
}
