#include <stdio.h>
#include <math.h>

struct Ponto {
    int x;
    int y;
};

int main() {

    struct Ponto ponto1, ponto2;

    printf("Digite as coordenadas do primeiro ponto (x y): ");
    scanf("%d %d", &ponto1.x, &ponto1.y);


    printf("Digite as coordenadas do segundo ponto (x y): ");
    scanf("%d %d", &ponto2.x, &ponto2.y);
    double distancia = sqrt(pow(ponto2.x - ponto1.x, 2) + pow(ponto2.y - ponto1.y, 2));
    printf("A dist�ncia entre os dois pontos �: %.2lf\n", distancia);

    return 0;
}
