#include <stdio.h>

int stringParaInteiro(const char *str) {
    int resultado = 0;
    int sinal = 1;
    int i = 0;

    // Verifica o sinal (positivo ou negativo)
    if (str[0] == '-') {
        sinal = -1;
        i = 1;
    }
    while (str[i] != '\0') {
        if (str[i] >= '0' && str[i] <= '9') {
            resultado = resultado * 10 + (str[i] - '0');
        } else {
            printf("Erro: Caractere nao numerico encontrado: '%c'\n", str[i]);
            return 0;
        }
        i++;
    }

    return resultado * sinal;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: %s <numero1> <numero2>\n", argv[0]);
        return 1;
    }
    int numero1 = stringParaInteiro(argv[1]);
    int numero2 = stringParaInteiro(argv[2]);

    if (numero1 == 0 || numero2 == 0) {
        return 1;
    }
    int soma = numero1 + numero2;

    printf("A soma de %d e %d e igual a %d\n", numero1, numero2, soma);

    return 0;
}
