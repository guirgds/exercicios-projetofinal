#include <stdio.h>
#include <string.h>

int main() {
    char original[100];
    char invertida[100];
    int i, j;
    printf("Digite uma string: ");
    gets(original);
    int tamanho = strlen(original);
    i = tamanho - 1;
    j = 0;

    while (i >= 0) {
        invertida[j] = original[i];
        i--;
        j++;
    }
    invertida[j] = '\0';
    printf("String original: %s\n", original);
    printf("String invertida: %s\n", invertida);

    return 0;
}
