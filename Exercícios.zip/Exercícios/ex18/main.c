#include <stdio.h>

int main() {
    int y, *p, x;

    y = 0;      // Inicializa y com 0
    p = &y;     // p aponta para o endere�o de y
    x = *p;     // x recebe o valor apontado por p (0)
    x = 4;      // x agora � atribu�do como 4
    (*p)++;     // Incrementa o valor apontado por p (y) em 1 (y agora � 1)
    x--;        // Decrementa x em 1 (x agora � 3)
    (*p) += x;  // Incrementa o valor apontado por p (y) pelo valor de x (3), y agora � 6

    printf("y = %d\n", y); // Imprime o valor de y, que � 6

    return 0;
}
