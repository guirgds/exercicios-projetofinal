#include <stdio.h>

int main() {
    int matriz_int[3][3];
    float matriz_float[3][3];
    double matriz_double[3][3];

    printf("Digite uma matriz 3x3 de inteiros:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%d", &matriz_int[i][j]);
        }
    }

    printf("Digite uma matriz 3x3 de floats:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%f", &matriz_float[i][j]);
        }
    }

    printf("Digite uma matriz 3x3 de doubles:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%lf", &matriz_double[i][j]);
        }
    }

    printf("Matriz de inteiros:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%5d ", matriz_int[i][j]);
        }
        printf("\n");
    }
    printf("Matriz de floats:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%8.2f ", matriz_float[i][j]);
        }
        printf("\n");
    }
    printf("Matriz de doubles:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%12.4lf ", matriz_double[i][j]);
        }
        printf("\n");
    }

    return 0;
}
