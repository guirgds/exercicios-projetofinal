#include <stdio.h>

int main() {
    char string1[100];  // Defina o tamanho m�ximo das strings
    char string2[100];

    // Solicite ao usu�rio que digite a primeira string
    printf("Digite a primeira string: ");
    scanf("%s", string1);

    // Solicite ao usu�rio que digite a segunda string
    printf("Digite a segunda string: ");
    scanf("%s", string2);

    // Imprima as duas strings
    printf("Primeira string: %s\n", string1);
    printf("Segunda string: %s\n", string2);

    // Verifique se as strings t�m pelo menos 2 caracteres antes de imprimir a segunda letra
    if (string1[1] != '\0') {
        printf("Segunda letra da primeira string: %c\n", string1[1]);
    } else {
        printf("A primeira string n�o tem pelo menos duas letras.\n");
    }

    if (string2[1] != '\0') {
        printf("Segunda letra da segunda string: %c\n", string2[1]);
    } else {
        printf("A segunda string n�o tem pelo menos duas letras.\n");
    }

    return 0;
}
