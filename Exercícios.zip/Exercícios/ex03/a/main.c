#include <stdio.h>

int main() {
    char caracter;


    printf("Digite um caractere: ");
    scanf(" %c", &caracter);


    printf("Caractere digitado: %c\n", caracter);
    printf("C�digo ASCII: %d\n", (int)caracter);

    return 0;
}
