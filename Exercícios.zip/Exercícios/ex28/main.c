#include <stdio.h>

void zerarVariaveis(int *a, int *b) {
    *a = 0;
    *b = 0;
}

int main() {
    int x = 10, y = 20;

    printf("Valores antes de zerar: x = %d, y = %d\n", x, y);

    zerarVariaveis(&x, &y);

    printf("Valores ap�s zerar: x = %d, y = %d\n", x, y);

    return 0;
}
