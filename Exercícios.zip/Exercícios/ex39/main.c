#include <stdio.h>

int main() {
    FILE *arquivo;
    char linha[100];
    char nome[100];
    int idade;

    arquivo = fopen("dados.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    printf("%-20s %-10s\n", "Nome", "Idade");
    printf("==================== ==========\n");
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        sscanf(linha, "%s %d", nome, &idade);
        printf("%-20s %-10d\n", nome, idade);
    }
    fclose(arquivo);

    return 0;
}
