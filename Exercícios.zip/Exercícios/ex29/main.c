#include <stdio.h>

void levetor(int *vet, int dimensao) {
    for (int i = 0; i < dimensao; i++) {
        printf("Digite o elemento %d: ", i + 1);
        scanf("%d", &vet[i]);
    }
}
int main() {
    int dimensao;

    printf("Digite a dimensao do vetor: ");
    scanf("%d", &dimensao);
    int vetor[dimensao];
    levetor(vetor, dimensao);
    printf("Vetor lido: ");
    for (int i = 0; i < dimensao; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
    return 0;
}
