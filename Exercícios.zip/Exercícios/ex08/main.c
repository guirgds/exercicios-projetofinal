#include <stdio.h>

int main() {
    int celsius;
    double fahrenheit;

    printf("Tabela de Convers�o de Celsius para Fahrenheit:\n");
    printf("Celsius\t\tFahrenheit\n");

    for (celsius = -100; celsius <= 100; celsius += 10) {
        fahrenheit = (9.0 / 5.0) * celsius + 32.0;
        printf("%d�C\t\t%.2f�F\n", celsius, fahrenheit);
    }

    return 0;
}
