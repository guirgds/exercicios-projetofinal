#include <stdio.h>
#include <string.h>

int main() {
    char palavra1[100];
    char palavra2[100];
    char palavra3[100];
    char palavra4[100];
    char resultado[400];

    printf("Digite a primeira palavra: ");
    scanf("%s", palavra1);

    printf("Digite a segunda palavra: ");
    scanf("%s", palavra2);

    printf("Digite a terceira palavra: ");
    scanf("%s", palavra3);

    printf("Digite a quarta palavra: ");
    scanf("%s", palavra4);

    strcpy(resultado, palavra1);
    strcat(resultado, " ");
    strcat(resultado, palavra2);
    strcat(resultado, " ");
    strcat(resultado, palavra3);
    strcat(resultado, " ");
    strcat(resultado, palavra4);
    printf("String resultante: %s\n", resultado);

    return 0;
}
