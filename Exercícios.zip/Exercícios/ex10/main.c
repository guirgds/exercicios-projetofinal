#include <stdio.h>

int main() {
    int numeroDia;
    printf("Digite o n�mero do dia (1 a 7): ");
    scanf("%d", &numeroDia);
    switch (numeroDia) {
        case 1:
            printf("Domingo\n");
            break;
        case 2:
            printf("Segunda-feira\n");
            break;
        case 3:
            printf("Ter�a-feira\n");
            break;
        case 4:
            printf("Quarta-feira\n");
            break;
        case 5:
            printf("Quinta-feira\n");
            break;
        case 6:
            printf("Sexta-feira\n");
            break;
        case 7:
            printf("S�bado\n");
            break;
        default:
            printf("N�mero de dia inv�lido. Insira um n�mero de 1 a 7.\n");
            break;
    }
    return 0;
}
