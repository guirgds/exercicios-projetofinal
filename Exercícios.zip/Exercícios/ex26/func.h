#ifndef FUNC_H
#define FUNC_H

int EDivisivel(int a, int b);

#endif
