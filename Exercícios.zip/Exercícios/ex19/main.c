#include <stdio.h>

size_t StrLen(const char *str) {
    const char *s = str;
    while (*s != '\0') {
        s++;
    }
    return (size_t)(s - str);
}
char *StrCat(char *dest, const char *src) {
    char *d = dest;
    const char *s = src;

    while (*d != '\0') {
        d++;
    }

    while (*s != '\0') {
        *d = *s;
        d++;
        s++;
    }

    *d = '\0';
    return dest;
}
int main() {
    char str1[100] = "Hello, ";
    char str2[] = "world!";
    size_t length = StrLen(str1);
    printf("Comprimento da string: %zu\n", length);
    StrCat(str1, str2);
    printf("Concatenado: %s\n", str1);

    return 0;
}
