#include <stdio.h>

int somar(int a, int b) {
    int resultado = a + b;
    return resultado;
}

int main() {
    int num1, num2, resultado;

    printf("Digite o primeiro n�mero: ");
    scanf("%d", &num1);

    printf("Digite o segundo n�mero: ");
    scanf("%d", &num2);

    resultado = somar(num1, num2);

    printf("A soma �: %d\n", resultado);

    return 0;
}
