#include <stdio.h>
#include <math.h>

int main() {
    double numero;

    printf("Este programa calcula o seno de �ngulos em radianos.\n");
    printf("Insira um �ngulo em radianos (0 para sair): ");

    while (1) {
        scanf("%lf", &numero);

        if (numero == 0.0) {
            printf("Programa encerrado.\n");
            break;
        }

        double seno = sin(numero);
        printf("O seno de %.2lf radianos � %.4lf.\n", numero, seno);

        printf("Insira outro �ngulo em radianos (0 para sair): ");
    }

    return 0;
}
