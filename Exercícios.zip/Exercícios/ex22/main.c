#include <stdio.h>

int main() {
    int matriz[100][100];

    // Inicializa a matriz com zeros
    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            matriz[i][j] = 0;
        }
    }
    int contador = 1;
    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            matriz[i][j] = contador;
            contador++;
        }
    }
    printf("Alguns valores da matriz:\n");
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            printf("%5d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
