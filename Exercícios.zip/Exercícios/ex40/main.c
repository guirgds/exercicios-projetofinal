#include <stdio.h>
#include <string.h>

int main() {
    FILE *arquivo;
    char linha[1000];
    char nome[100];
    char telefone[20];
    char endereco[100];
    int eof = 0;

    arquivo = fopen("dados.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    while (!eof) {

        nome[0] = '\0';
        telefone[0] = '\0';
        endereco[0] = '\0';

        while (fgets(linha, sizeof(linha), arquivo) != NULL) {
            if (strstr(linha, "Nome: ")) {
                strcpy(nome, linha + strlen("Nome: "));
            } else if (strstr(linha, "Telefone: ")) {
                strcpy(telefone, linha + strlen("Telefone: "));
            } else if (strstr(linha, "Endereco: ")) {
                strcpy(endereco, linha + strlen("Endereco: "));
                break;
        }
        if (nome[0] == '\0' || telefone[0] == '\0' || endereco[0] == '\0') {
            eof = 1;
        } else {
            strtok(nome, "\n");
            strtok(telefone, "\n");
            strtok(endereco, "\n");

            printf("Nome: %s\n", nome);
            printf("Telefone: %s\n", telefone);
            printf("Endereco: %s\n", endereco);
            printf("\n");
        }
    }

    fclose(arquivo);

    return 0;
}
