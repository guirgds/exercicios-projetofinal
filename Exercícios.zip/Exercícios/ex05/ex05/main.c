#include <stdio.h>


int varGlobal = 10;

int main() {
    int var1 = 20, var2 = 30, var3 = 40, var4 = 50, var5 = 60;
    char char1 = 'c', char2 = 'o', char3 = 'e', char4 = 'l', char5 = 'h', char6 = 'a';
    printf("As vari�veis inteiras cont�m os n�meros: %d, %d, %d, %d, %d, %d.\n",
           varGlobal, var1, var2, var3, var4, var5);
    printf("O animal contido nas vari�veis caracteres � a %c%c%c%c%c%c.\n",
           char1, char2, char3, char4, char5, char6);
    return 0;
}
