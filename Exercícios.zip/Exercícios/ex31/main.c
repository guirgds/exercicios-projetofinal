#include <stdio.h>
#include <string.h>

void trocarStrings(char *str1, char *str2) {
    char temp[strlen(str1) + 1];

    strcpy(temp, str1);
    strcpy(str1, str2);
    strcpy(str2, temp);
}

int main() {
    char string1[50], string2[50];

    printf("Digite a primeira string: ");
    scanf("%s", string1);

    printf("Digite a segunda string: ");
    scanf("%s", string2);

    printf("\nStrings antes da troca:\n");
    printf("String 1: %s\n", string1);
    printf("String 2: %s\n", string2);

    trocarStrings(string1, string2);

    printf("\nStrings depois da troca:\n");
    printf("String 1: %s\n", string1);
    printf("String 2: %s\n", string2);

    return 0;
}
