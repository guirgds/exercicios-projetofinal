#include <stdio.h>
#include <string.h>

int main() {
    char string[50];
    int i, count = 0;
    printf("Digite uma string: ");
    scanf("%s", string);
    int length = strlen(string);
    for (i = 0; i < length; i++) {
        if (string[i] == 'a') {
            string[i] = 'b';
            count++;
        }
    }
    printf("N�mero de caracteres modificados: %d\n", count);
    printf("String modificada: %s\n", string);
    return 0;
}
