#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 10 // Tamanho da matriz (10x10)
#define MAX_ITERATIONS 1000 // N�mero m�ximo de itera��es

// Fun��o para imprimir a matriz no terminal
void printMatrix(int matrix[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

// Fun��o para verificar se uma posi��o est� dentro dos limites da matriz
int isValidPosition(int x, int y) {
    return (x >= 0 && x < SIZE && y >= 0 && y < SIZE);
}

// Fun��o para adicionar uma part�cula aleatoriamente ao redor de uma part�cula vizinha
void addParticle(int aggregate[SIZE][SIZE], int x, int y) {
    int emptySpaces[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    int indices[4];
    int count = 0;
    for (int i = 0; i < 4; i++) {
        int newX = x + emptySpaces[i][0];
        int newY = y + emptySpaces[i][1];
        if (isValidPosition(newX, newY) && aggregate[newX][newY] == 0) {
            indices[count++] = i;
        }
    }
    if (count == 0) {
        return;
    }
    int randomIndex = rand() % count;
    int direction = indices[randomIndex];
    int newX = x + emptySpaces[direction][0];
    int newY = y + emptySpaces[direction][1];
    aggregate[newX][newY] = 1;
}

int main() {
    srand(time(NULL)); // Inicializa o gerador de n�meros aleat�rios

    int aggregate[SIZE][SIZE] = {0}; // Inicializa a matriz do agregado com zeros

    // Inicializa o agregado com duas part�culas em posi��es aleat�rias
    int x1 = rand() % SIZE;
    int y1 = rand() % SIZE;
    int x2, y2;
    do {
        x2 = rand() % SIZE;
        y2 = rand() % SIZE;
    } while (x2 == x1 && y2 == y1); // Verifica se a segunda part�cula est� em uma posi��o diferente da primeira
    aggregate[x1][y1] = 1;
    aggregate[x2][y2] = 1;

    // Imprime a matriz inicial no terminal
    printf("Matriz inicial do agregado:\n");
    printMatrix(aggregate);

    int iterations = 0;
    while (1) {
        int changed = 0; // Flag para verificar se alguma part�cula foi adicionada nesta itera��o

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (aggregate[i][j] == 1) {
                    // Verifica se h� uma part�cula vizinha
                    if ((i > 0 && aggregate[i - 1][j] == 0) ||
                        (i < SIZE - 1 && aggregate[i + 1][j] == 0) ||
                        (j > 0 && aggregate[i][j - 1] == 0) ||
                        (j < SIZE - 1 && aggregate[i][j + 1] == 0)) {
                        addParticle(aggregate, i, j);
                        changed = 1; // Marca que uma part�cula foi adicionada
                        break; // Sai do loop interno para adicionar apenas uma part�cula por itera��o
                    }
                }
            }
            if (changed) {
                break; // Sai do loop externo se uma part�cula foi adicionada
            }
        }

        if (!changed || iterations >= MAX_ITERATIONS) {
            break; // Sai do loop se n�o houver mais part�culas adicionadas ou atingir o n�mero m�ximo de itera��es
        }

        iterations++;

        // Imprime a matriz ap�s cada itera��o
        printf("Itera��o %d:\n", iterations);
        printMatrix(aggregate);
    }

    // Imprime a matriz final do agregado no terminal
    printf("Matriz final do agregado:\n");
    printMatrix(aggregate);

    return 0;
}
